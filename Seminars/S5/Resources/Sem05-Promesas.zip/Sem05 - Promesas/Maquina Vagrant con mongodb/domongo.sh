export PATH=/home/vagrant/mongodb-linux-x86_64-3.4.9/bin:$PATH
mongod $1
